#ifndef ship_h
#define ship_h

#define SHIP_SIZE 10

#define ROTATE_AMOUNT 6
#define THRUST_AMOUNT 0.5
#include "flyingObject.h"



// Put your Ship class here
class Ship : public FlyingObject
{
  private:
   int rotation;
  public:
	 Ship()
	 {
		 location = Point();
		 alive = true;
     rotation = 0;
	 }
  
	 int getRotation()  const { return rotation; }
	virtual void draw();
	void turnRight();
	void turnLeft();
	void thrust();
	void breaks();
	void advance();

};

#endif /* ship_h */
