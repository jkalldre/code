#ifndef flyingObject_h
#define flyingObject_h
#include "point.h"
#include "velocity.h"


// Put your FlyingObject class here
class FlyingObject
{
protected:
	bool alive;
	Point location;
	Velocity velocity;
	int radius;

public:
	void advance()            {}
	virtual void draw() = 0;
	bool isAlive()      const { return alive; }  
	void kill()               { alive = false; }
	int getSize()       const { return radius; }
	Velocity getVelocity() const { return velocity;         }
	Point getPoint()    const { return location; }
	float getDx()       const { return velocity.getDx(); }
	float getDy()       const { return velocity.getDy(); }
};



#endif /* flyingObject_h */
