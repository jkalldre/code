#ifndef rocks_h
#define rocks_h

#define BIG_ROCK_SIZE 16
#define MEDIUM_ROCK_SIZE 8
#define SMALL_ROCK_SIZE 4

#define BIG_ROCK_SPIN 2
#define MEDIUM_ROCK_SPIN 5
#define SMALL_ROCK_SPIN 10
#include "flyingObject.h"
#include <list>


// Define the following classes here:
//   Rock
class Rock : public FlyingObject
{
protected:
public:
	virtual void draw() {}
	void breakApart(std::list<Rock*> &r) {}
};
//   BigRock
class BigRock : public Rock
{
private:
public:
	BigRock(Point p) {}
	//void breakApart(Rock* r) {}
};

//   MediumRock
class MediumRock : public Rock
{
private:
public:
	//void breakApart(Rock* r) {}
};

//   SmallRock
class SmallRock : public Rock
{
private:
public:
	//void breakApart(Rock* r) {}
};



#endif /* rocks_h */
