#ifndef bullet_h
#define bullet_h

#define BULLET_SPEED 5
#define BULLET_LIFE 40
#include "flyingObject.h"
#include "ship.h"

// Put your Bullet class here
class Bullet : public FlyingObject
{
private:
public:
	Bullet(Ship s) {}
	virtual void draw() {}
};



#endif /* bullet_h */
