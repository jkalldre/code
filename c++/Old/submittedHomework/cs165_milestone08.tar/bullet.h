#ifndef BULLET_H
#define BULLET_H
#include "flyingObject.h"

class Bullet : public flyingObject
{
  public:
	  Bullet();
	  ~Bullet() {}
	  
	  void advance(float a);
	  bool shot;
	  void shoot() { shot = true; }
	  
	  float gunAngle;
	  void draw();
	  float getY()             { return location.getY(); }
	  float getX()             { return location.getX(); }
	  bool getOnScreen()       { return onScreen; }
	  bool getShot() { return shot; }
	  void setOnScreen(bool b) { onScreen = b; }

  private:
	  bool onScreen;

};


#endif 
