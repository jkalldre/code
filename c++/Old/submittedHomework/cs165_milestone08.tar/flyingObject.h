#ifndef FLYINGOBJECT_H
#define FLYINGOBJECT_H
#include "point.h"
#include "velocity.h"
#include "uiDraw.h"

class flyingObject
{
  protected:
   Point location;
   Velocity velocity;

  public:
	  void draw();
};

#endif
