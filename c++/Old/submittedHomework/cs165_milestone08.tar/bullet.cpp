#include "bullet.h"
#include <iostream>


Bullet::Bullet()
{
	location = Point(200, -200);
	onScreen = false;
	velocity = Velocity();
	shot = false;
	
}

void Bullet::draw()
{
	drawDot(location);
}


void Bullet::advance(float a)
{
	velocity.setDy(( (10.0 * cos(3.14159 / 180.0 * a))));
	velocity.setDx(( (10.0 * -sin(3.14159 / 180.0 * a))));

	location.addX(velocity.getDx()/10);
	location.addY(velocity.getDy()/10);
}