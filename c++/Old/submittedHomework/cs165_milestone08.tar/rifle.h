#ifndef RIFLE_H
#define RIFLE_H
#include "point.h"
#include "uiDraw.h"

class Rifle
{
private:
	Point location;
	float angle;
	Point gunEnd;

public:
	Rifle();
	void rotateUp();
	void rotateDown();
	void draw();
	
	Point getLocation()
	{
		return location;
	}
	int getAngle()
	{
		return angle;
	}
	Point getGunEnd();

	int setAngle(int a)
	{
		angle = a;
	}

};
#endif