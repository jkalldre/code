/****************************************
 * The game of Skeet
 ****************************************/

#include "uiDraw.h"
#include "uiInteract.h"
#include "point.h"
#include "bullet.h"
#include "rifle.h"
#define _USE_MATH_DEFINES
#include <cmath>


/*****************************************
 * GAME
 * The main game class containing all the state
 *****************************************/
class Game
{
public:
   // create the game
   Game(Point tl, Point br) : topLeft(tl), bottomRight(br) { }
   
   // handle user input
   void handleInput(const Interface & ui);

   // advance the game
   void advance();
         
   // draw stuff
   void draw(const Interface & ui);
   
private:
   Point topLeft;
   Point bottomRight;

   // TODO: add any objects or variables that are required
   Rifle rifle;
   Bullet bullet;
   int numBullet;
};

/***************************************
 * GAME :: ADVANCE
 * advance the game one unit of time
 ***************************************/
void Game :: advance()
{
	if (bullet.getShot() == true)
	   bullet.advance(rifle.getAngle());
	if (bullet.getX() < -200 || bullet.getY() > 200)
	{
		bullet.~Bullet();
		//bullet.setOnScreen(false);
		//numBullet--;
		//if (!bullet.getOnScreen())
		//{	
			//numBullet--;
		//}
		//delete [0] pBArray;
		//std::cout << numBullet;
	//}
	}
}

/***************************************
 * GAME :: input
 * accept input from the user
 ***************************************/
void Game :: handleInput(const Interface & ui)
{
   // TODO: handle user input
	if (ui.isRight() && rifle.getAngle() > 0)
		rifle.rotateUp();

	if (ui.isLeft() && rifle.getAngle() < 90)
		rifle.rotateDown();

	if (ui.isSpace())
	{
		bullet.shoot();
		bullet.setOnScreen(true);
		
	}
}

/*********************************************
 * GAME :: DRAW
 * Draw everything on the screen
 *********************************************/
void Game :: draw(const Interface & ui)
{
   // TODO: Draw the various elements of the game
	rifle.draw();

	if (bullet.getOnScreen() == true)
		bullet.draw();
}


/*************************************
 * All the interesting work happens here, when
 * I get called back from OpenGL to draw a frame.
 * When I am finished drawing, then the graphics
 * engine will wait until the proper amount of
 * time has passed and put the drawing on the screen.
 **************************************/
void callBack(const Interface *pUI, void *p)
{
   Game *pGame = (Game *)p;
   
   pGame->advance();
   pGame->handleInput(*pUI);
   pGame->draw(*pUI);
}


/*********************************
 * Main is pretty sparse.  Just initialize
 * the game and call the display engine.
 * That is all!
 *********************************/
int main(int argc, char ** argv)
{
   Point topLeft(-200, 200);
   Point bottomRight(200, -200);

   Interface ui(argc, argv, "Skeet", topLeft, bottomRight);
   Game game(topLeft, bottomRight);
   ui.run(callBack, &game);
   
   return 0;
}
