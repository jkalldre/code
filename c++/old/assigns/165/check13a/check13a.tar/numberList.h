/*******************
 * NumberList class
 *******************/
#ifndef NUMBER_LIST_H
#define NUMBER_LIST_H

#include <iostream>

class NumberList
{
private:
   int size;
   int *array;

public:
   NumberList()
   {
      size = 0;
      array = NULL;
   }


   // TODO: Add your constructor and destructor
   NumberList(int s)
   {
      array = new int[s];
      size = s;
      for(int i = 0; i < size; i++)
         array[i] = 0;
   }
   
   ~NumberList()
   {
      delete [] array;
      array = NULL;
      std::cout << "Freeing memory\n";
   }


   int getNumber(int index) const;
   void setNumber(int index, int value);
   
   void displayList() const;

};

#endif
